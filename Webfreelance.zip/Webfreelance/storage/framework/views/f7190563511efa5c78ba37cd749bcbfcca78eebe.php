<?php $__env->startSection('title','Tài khoản'); ?>
<?php $__env->startSection('con','Thêm tài khoản'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="animated fadeIn">
		<div class="row">
			<div class="col-md-8">
				<div class="card">
					<div class="card-header">
						<strong>Thêm mới tài khoản</strong>
					</div>
					<div class="card-block">
						<form action="" method="post" enctype="multipart/form-data">
							<div class="form-group">
								<label for="nf-email">Tên</label>
								<input type="text" id="nf-email" name="name" class="form-control" value="<?php echo e(old('name')); ?>">
								<?php if($errors->has('name')): ?>
									<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
								<?php endif; ?>
							</div>
							<div class="form-group">
								<label for="nf-email">Email</label>
								<input type="text" id="nf-email" name="email" class="form-control" value="<?php echo e(old('email')); ?>">
								<?php if($errors->has('email')): ?>
									<span class="text-danger"><?php echo e($errors->first('email')); ?></span>
								<?php endif; ?>
							</div>
							<div class="form-group">
								<label for="nf-email">Số điện thoại</label>
								<input type="text" id="nf-email" name="phone" class="form-control" value="<?php echo e(old('phone')); ?>">
								<?php if($errors->has('email')): ?>
									<span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
								<?php endif; ?>
							</div>
							<div class="form-group">
                               <label for="nf-email">File ảnh</label>
                               <input type="file" id="file-input" name="image">
								<?php if($errors->has('image')): ?>
									<span class="text-danger"><?php echo e($errors->first('image')); ?></span>
								<?php endif; ?>
                                </div>
							<div class="form-group">
								<label for="nf-email">Mật khẩu</label>
								<input type="password" id="nf-email" name="password" class="form-control">
								<?php if($errors->has('password')): ?>
									<span class="text-danger"><?php echo e($errors->first('password')); ?></span>
								<?php endif; ?>
							</div>
							<div class="form-group">
								<label for="nf-email">Nhập lại mật khẩu</label>
								<input type="password" id="nf-email" name="re_password" class="form-control">
								<?php if($errors->has('re_password')): ?>
									<span class="text-danger"><?php echo e($errors->first('re_password')); ?></span>
								<?php endif; ?>
							</div>
							<div class="form-group row">
                                            <label class="col-md-3 form-control-label">Trạng thái</label>
                                            <div class="col-md-9">
                                                <label class="radio-inline" for="inline-radio1">
                                                    <input type="radio" id="inline-radio1" name="status" value="1" checked>Hiện
                                                </label>
                                                <label class="radio-inline" for="inline-radio2">
                                                    <input type="radio" id="inline-radio2" name="status" value="0">Ẩn
                                                </label>
                                            </div>
                            </div>
					
					</div>
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<div class="card-footer">
						<button type="submit" class="btn btn-sm btn-primary"><i class="fa fa-dot-circle-o"></i> Thêm mới</button>
					</div>
						
				</div>
				</form>                                               
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>