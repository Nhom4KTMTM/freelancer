<?php $__env->startSection('title','Quản lý tin'); ?>
<?php $__env->startSection('con','Tin hết hạn'); ?>
<?php $__env->startSection('content'); ?>
 <div class="container-fluid">
                <div class="animated fadeIn">
                    <div class="card">
                        <div class="card-header">
                            <i class="fa fa-edit"></i> Tin đang đăng
                            
                        </div>
                        <div class="card-block">
                            <table class="table table-striped table-bordered datatable">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Người đăng</th>
                                        <th>Tiêu đề tin</th>
                                        <th>Thể loại</th>
                                        <th>Ngày tạo</th>
                                        <th>Ngày hết hạn</th>
                                        <th>Hành động</th>
                                    </tr>
                                </thead>
                                <tbody>
                                   <?php $__currentLoopData = $new; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($new->id); ?></td>
                                        <td><?php echo e($new->khachhang->name); ?></td>
                                        <td><?php echo e($new->name); ?></td>
                                        <td><?php echo e($new->linhvuctin->name); ?></td>
                                        <td><?php echo e($new->created_at); ?></td>
                                        <td><?php echo e($new->tg_hethan); ?></td>
                                        <td>
                                            <a class="btn btn-success" href="<?php echo e(route('backend.chitiettinhethan',['id'=>$new->id])); ?>" title="" ><i class="fa fa-search-plus"></i></a>
                                            <a class="btn btn-danger" href="<?php echo e(route('backend.xoatin',['id'=>$new->id])); ?>">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>