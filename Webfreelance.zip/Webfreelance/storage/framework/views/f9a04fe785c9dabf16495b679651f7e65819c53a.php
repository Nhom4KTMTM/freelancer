<?php $__env->startSection('title','Danh mục'); ?>
<?php $__env->startSection('content'); ?>
 <div class="container-fluid">
    <div class="animated fadeIn">
                    <div class="card">
                        <div class="card-header">
                            <i class="fa fa-edit"></i> Danh mục
                            <div class="card-actions">
                                <a href="http://l-lin.github.io/angular-datatables/#/gettingStarted">
                                    <small class="text-muted">docs</small>
                                </a>
                            </div>
                        </div>
                        <div class="card-block">
                            <table class="table table-striped table-bordered datatable">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Tên danh mục</th>
                                        <th>Hình ảnh</th>
                                        <th>Danh mục cha</th>
                                        <th>Trạng thái</th>
                                        <th>Hành động</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($cat->id); ?></td>
                                        <td><?php echo e($cat->name); ?></td>
                                        <td><img src="<?php echo e(url('Uploads/image')); ?>/<?php echo e($cat->image); ?>" alt="" width="100px"></td>
                                        <td>
                                             <?php if($cat->cat_parent): ?>
                                                 <?php echo e($cat->cat_parent->name); ?>

                                             <?php else: ?>
                                                  Danh mục cha
                                              <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($cat->status==0): ?>
                                          <span class="label label-default label-lg">Ẩn</span>
                                          <?php else: ?>  
                                          <span class="label label-primary label-lg">Hiện</span>
                                          <?php endif; ?>
                                        </td>
                                        <td>
                                           
                                            <a class="btn btn-info" href="<?php echo e(route('backend.suadanhmuc',['id'=>$cat->id])); ?>">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="<?php echo e(route('backend.xoadanhmuc',['id'=>$cat->id])); ?>">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>