<p>Công việc bạn đã được đăng thành công</p>
<p><strong>Tiêu đề: </strong><span><?php echo e($name); ?></span></p>
<p>Việc đăng của bạn đã được chấp thuận</p>
<p>Freelance hỗ trợ bạn tìm freelancer thực hiện theo dự án. </p>