<?php $__env->startSection('title','Banner'); ?>
<?php $__env->startSection('con','Thêm banner'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <strong>Thêm mới banner</strong>
                    </div>
                    <div class="card-block">
                        <form action="" method="post" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="nf-email">Tên banner</label>
                                <input type="text" id="nf-email" name="name" class="form-control" value="<?php echo e($slider->name); ?>">
                                <?php if($errors->has('name')): ?>
                                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="nf-email">Đường dẫn</label>
                                <input type="text" id="nf-email" name="link" class="form-control" value="<?php echo e($slider->link); ?>">
                                <?php if($errors->has('link')): ?>
                                <span class="text-danger"><?php echo e($errors->first('link')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="nf-email">Thứ tự</label>
                                <input type="text" id="nf-email" name="thutu" class="form-control" value="<?php echo e($slider->thutu); ?>">
                                <?php if($errors->has('thutu')): ?>
                                <span class="text-danger"><?php echo e($errors->first('thutu')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="nf-email">File ảnh</label>
                                <div>
                                    <img src="<?php echo e(url('Uploads/image')); ?>/<?php echo e($slider->image); ?>" alt="" width="200px"><br><br>
                                </div> 
                                
                                <input type="file" id="file-input" name="image">
                                <?php if($errors->has('image')): ?>
                                <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-3 form-control-label">Trạng thái</label>
                                <div class="col-md-9">
                                    <label class="radio-inline" for="inline-radio1">
                                        <input type="radio" id="inline-radio1" name="status" value="1" <?php if($slider->status==1): ?> checked <?php endif; ?>>Hiện
                                    </label>
                                    <label class="radio-inline" for="inline-radio2">
                                        <input type="radio" id="inline-radio2" name="status" value="0" <?php if($slider->status==1): ?> checked <?php endif; ?>>Ẩn
                                    </label>
                                </div>
                            </div>
                            
                        </div>
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="card-footer">
                            <button type="submit" class="btn btn-sm btn-primary"><i class="fa fa-dot-circle-o"></i> Cập nhật</button>
                        </div>
                        
                    </div>
                </form>                                               
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>