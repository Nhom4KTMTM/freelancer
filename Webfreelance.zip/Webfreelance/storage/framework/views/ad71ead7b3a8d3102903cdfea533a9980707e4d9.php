<?php $__env->startSection('content'); ?>
        <ol class="breadcrumb r-0">
            <li><a href="#">Home</a></li>
            <li><a href="#">Tổng quan</a></li>
            <li class="active">Tổng quan</li>
        </ol>
<div class="container-fluid">
	<div class="animated fadeIn">
                    <div class="row row-equal">
                        <div class="col-sm-6 col-md-6">
                            <div class="card card-inverse card-info">
                                <div class="card-block">
                                    <div class="h1 text-muted text-xs-right m-b-2">
                                        <i class="icon-people"></i>
                                    </div>
                                    <div class="h4 m-b-0">87.500</div>
                                    <small class="text-muted text-uppercase font-weight-bold">Việc đã đăng</small>
                                    
                                </div>
                            </div>
                        </div>
                        <!--/col-->
                        <!--/col-->
                        <div class="col-sm-6 col-md-6">
                            <div class="card card-inverse card-success">
                                <div class="card-block">
                                    <div class="h1 text-muted text-xs-right m-b-2">
                                        <i class="icon-speech"></i>
                                    </div>
                                    <div class="h4 m-b-0">972</div>
                                    <small class="text-muted text-uppercase font-weight-bold">Việc cần phê duyệt</small>                                    
                                </div>
                            </div>
                        </div>
                        <!--/col-->
                        <!--/col-->
                    </div>
                    <!--/row-->
                    <div class="card">
                        <div class="card-header">
                            Việc cần phê duyệt
                        </div>
                        <div class="card-block">
                            <div class="row">
                               <div class="card">
                            <table class="table table-striped table-bordered datatable">
                                <thead>
                                    <tr>
                                        <th>Tên người đăng</th>
                                        <th>Thể loại</th>
                                        <th>Tiêu đề</th>
                                        <th>Thời gian đăng</th>
                                        <th width="200px">Hoạt động</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Anton Phunihel</td>
                                        <td>Lập trình web</td>
                                        <td>Lập trình trang web trường tiểu học Hà Nội</td>
                                        <td>
                                            20/12/2018
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#" title="Xem chi tiết">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#" title="Kích hoạt">
                                                <i class="fa fa-check-square-o"></i>
                                            </a>
                                            <a class="btn btn-danger" href="#" title="Xóa">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Clemens Janko</td>
                                        <td>2012/02/01</td>
                                        <td>Staff</td>
                                        <td>
                                            <span class="label label-danger">Banned</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Chidubem Gottlob</td>
                                        <td>2012/02/01</td>
                                        <td>Staff</td>
                                        <td>
                                            <span class="label label-danger">Banned</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Hristofor Sergio</td>
                                        <td>2012/03/01</td>
                                        <td>Member</td>
                                        <td>
                                            <span class="label label-warning">Pending</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Tadhg Griogair</td>
                                        <td>2012/03/01</td>
                                        <td>Member</td>
                                        <td>
                                            <span class="label label-warning">Pending</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Pollux Beaumont</td>
                                        <td>2012/01/21</td>
                                        <td>Staff</td>
                                        <td>
                                            <span class="label label-success">Active</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Adam Alister</td>
                                        <td>2012/01/21</td>
                                        <td>Staff</td>
                                        <td>
                                            <span class="label label-success">Active</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#" title="hello">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Carlito Roffe</td>
                                        <td>2012/08/23</td>
                                        <td>Staff</td>
                                        <td>
                                            <span class="label label-danger">Banned</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Sana Amrin</td>
                                        <td>2012/08/23</td>
                                        <td>Staff</td>
                                        <td>
                                            <span class="label label-danger">Banned</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Adinah Ralph</td>
                                        <td>2012/06/01</td>
                                        <td>Admin</td>
                                        <td>
                                            <span class="label label-default">Inactive</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Dederick Mihail</td>
                                        <td>2012/06/01</td>
                                        <td>Admin</td>
                                        <td>
                                            <span class="label label-default">Inactive</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Hipólito András</td>
                                        <td>2012/03/01</td>
                                        <td>Member</td>
                                        <td>
                                            <span class="label label-warning">Pending</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Fricis Arieh</td>
                                        <td>2012/03/01</td>
                                        <td>Member</td>
                                        <td>
                                            <span class="label label-warning">Pending</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Scottie Maximilian</td>
                                        <td>2012/03/01</td>
                                        <td>Member</td>
                                        <td>
                                            <span class="label label-warning">Pending</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Bao Gaspar</td>
                                        <td>2012/01/01</td>
                                        <td>Member</td>
                                        <td>
                                            <span class="label label-success">Active</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Tullio Luka</td>
                                        <td>2012/02/01</td>
                                        <td>Staff</td>
                                        <td>
                                            <span class="label label-danger">Banned</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Felice Arseniy</td>
                                        <td>2012/02/01</td>
                                        <td>Admin</td>
                                        <td>
                                            <span class="label label-default">Inactive</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Finlay Alf</td>
                                        <td>2012/02/01</td>
                                        <td>Admin</td>
                                        <td>
                                            <span class="label label-default">Inactive</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Theophilus Nala</td>
                                        <td>2012/03/01</td>
                                        <td>Member</td>
                                        <td>
                                            <span class="label label-warning">Pending</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Sullivan Robert</td>
                                        <td>2012/03/01</td>
                                        <td>Member</td>
                                        <td>
                                            <span class="label label-warning">Pending</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Kristóf Filiberto</td>
                                        <td>2012/01/21</td>
                                        <td>Staff</td>
                                        <td>
                                            <span class="label label-success">Active</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Kuzma Edvard</td>
                                        <td>2012/01/21</td>
                                        <td>Staff</td>
                                        <td>
                                            <span class="label label-success">Active</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Bünyamin Kasper</td>
                                        <td>2012/08/23</td>
                                        <td>Staff</td>
                                        <td>
                                            <span class="label label-danger">Banned</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Crofton Arran</td>
                                        <td>2012/08/23</td>
                                        <td>Staff</td>
                                        <td>
                                            <span class="label label-danger">Banned</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Bernhard Shelah</td>
                                        <td>2012/06/01</td>
                                        <td>Admin</td>
                                        <td>
                                            <span class="label label-default">Inactive</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Grahame Miodrag</td>
                                        <td>2012/03/01</td>
                                        <td>Member</td>
                                        <td>
                                            <span class="label label-warning">Pending</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Innokentiy Celio</td>
                                        <td>2012/03/01</td>
                                        <td>Member</td>
                                        <td>
                                            <span class="label label-warning">Pending</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#" title="Xem chi tiết">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#" title="Kích hoạt">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#" title="Xóa">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Kostandin Warinhari</td>
                                        <td>2012/03/01</td>
                                        <td>Member</td>
                                        <td>
                                            <span class="label label-warning">Pending</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Ajith Hristijan</td>
                                        <td>2012/03/01</td>
                                        <td>Member</td>
                                        <td>
                                            <span class="label label-warning">Pending</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="#">
                                                <i class="fa fa-search-plus "></i>
                                            </a>
                                            <a class="btn btn-info" href="#">
                                                <i class="fa fa-edit "></i>
                                            </a>
                                            <a class="btn btn-danger" href="#">
                                                <i class="fa fa-trash-o "></i>
                                            </a>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                            </div>
                        </div>
                    </div>
                    <!--/.card-->
                    <!--/.row-->
                    <!--/.row-->
                </div>	
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>