<?php $__env->startSection('title','Khách hàng'); ?>
<?php $__env->startSection('content'); ?>
 <div class="container-fluid">
    <div class="animated fadeIn">
                    <div class="card">
                        <div class="card-header">
                            <i class="fa fa-edit"></i> Khách hàng
                            <div class="card-actions">
                                <a href="http://l-lin.github.io/angular-datatables/#/gettingStarted">
                                    <small class="text-muted">docs</small>
                                </a>
                            </div>
                        </div>
                        <div class="card-block">
                            <table class="table table-striped table-bordered datatable">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Ảnh</th>
                                        <th>Tên Khách hàng</th>
                                        <th>Email</th>
                                        <th>Số điện thoại</th>
                                        <th>Lĩnh vực</th>
                                        <th>Tiền kiếm được</th>
                                        <th>Hành động</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($cat->id); ?></td>
                                        
                                        <td><img src="<?php echo e(url('Uploads/image')); ?>/<?php echo e($cat->image); ?>" alt="" width="120px"></td>
                                        <td><?php echo e($cat->name); ?></td>
                                        <td><?php echo e($cat->email); ?></td>
                                        <td><?php echo e($cat->phone); ?></td>
                                        <td><?php echo e($cat->linhvucc->name); ?></td>
                                        <td><?php echo e(number_format($cat->money)); ?></td>
                                        <td>
                                           
                                            <a class="btn btn-info" href="<?php echo e(route('backend.chitiet',['id'=>$cat->id])); ?>">
                                                <i class="fa fa-search-plus"></i>
                                            </a>
                                            
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>