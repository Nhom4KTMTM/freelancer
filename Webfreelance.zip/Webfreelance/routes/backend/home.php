<?php 
Route::get('/', function() {
    return view('Home.home');
});
 ?>