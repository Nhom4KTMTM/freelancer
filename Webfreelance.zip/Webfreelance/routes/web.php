<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::group(['prefix' => 'admin','namespace'=>'Backend'], function() {
    //
    require_once 'backend/home.php';
    require_once 'backend/home.php';
    require_once 'backend/category.php';
    require_once 'backend/city.php';
    require_once 'backend/user.php';
    require_once 'backend/customer.php';
    require_once 'backend/new.php';
    require_once 'backend/banner.php';
});

// Route::get('danh-muc', function() {
//     return view('Category.index');
// });
// Route::get('them-danh-muc', function() {
//     return view('Category.create');
// });
// Route::get('thanh-pho', function() {
//     return view('City.index');
// });
// Route::get('tin-can-phe-duyet', function() {
//     return view('news.tincanpheduyet');
// });
// Route::get('tin-dang-dang', function() {
//     return view('news.tindangdang');
// });
// Route::get('tin-het-han', function() {
//     return view('news.tinhethan');
// });

