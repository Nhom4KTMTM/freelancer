<p>Công việc bạn vừa đăng đã được chúng tôi gỡ xuống</p>
<p><strong>Tiêu đề: </strong><span>{{$name}}</span></p>
<p><strong>Lý do: </strong><span>Nội dung spam</span></p>
<p>Freelance hỗ trợ bạn tìm freelancer thực hiện theo dự án. Để tránh việc spam và gây phiền phức tới freelancer khác đang tìm việc, bạn vui lòng cân nhắc kỹ nội dung trước khi đăng.
vLance hy vọng sẽ tiếp tục hợp tác với bạn trong thời gian tới.</p>