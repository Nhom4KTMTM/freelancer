<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\work;
class HomeController extends Controller
{
    public function index()
    {
    	$tongviecdang = Work::where('status','!=','1')->count();
    	$tongvieccanpheduyet = Work::where('status','=','0')->count();
    	$new=Work::where('status',0)->get();
    	return view('Home.home',compact('new','tongviecdang','tongvieccanpheduyet'));
    }

    public function pheduyet($id)
    {
        Work::where('id',$id)->update(['status'=>1]);
        $id_nguoithue = Work::find($id)->id_nguoithue;
        $user = User::find($id_nguoithue);
        $work =  Work::find($id);
        $data = ['name' => $work->name];
        $this->email = $user->email;
        Mail::send('Email.dangviec', $data, function ($message) {
            $message->from('lequochuysv@gmail.com', 'Freelance');
            $message->to($this->email)->subject('Đăng việc thành công trên Freelance');
        });
        return redirect()->route('backend.home')->with('success','Phê duyệt thành công');
    } 
}