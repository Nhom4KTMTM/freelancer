<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Work extends Model
{
    //
    protected $table='work';

    protected $fillable=[
    	'id_nguoithue','content','linhvuc','name','tg_hethan','city','money','status'
    ];
    public function khachhang()
    {
    	return $this->hasOne('App\Models\User','id','id_nguoithue');
    }
    public function linhvuctin()
    {
    	# code...
    	return $this->hasOne('App\Models\Category','id','linhvuc');
    }
    public function thanhpho()
    {
    	# code...
    	return $this->hasOne('App\Models\City','id','city');
    }
}
